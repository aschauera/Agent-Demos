# Copilot Studio and Azure AI Foundry / Bot Service Agent Demos & Samples
Demonstrations and samples for Power Platform and Azure based agents and autonmous agents
